--
-- Estrutura da tabela `compra`
--

CREATE TABLE `compra` (
  `id` int(11) NOT NULL,
  `nomoeda` varchar(1000) NOT NULL,
  `endereco` varchar(150) NOT NULL,
  `usd` varchar(100) NOT NULL,
  `moeda` varchar(1000) NOT NULL,
  `nome` varchar(1000) NOT NULL,
  `email` varchar(1000) NOT NULL,
  `telefone` varchar(50) NOT NULL,
  `telefone_b` varchar(50) NOT NULL,
  `data` varchar(50) NOT NULL,
  `id_one` varchar(50) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `status` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- AUTO_INCREMENT de tabela `compra`
--
ALTER TABLE `compra`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `compra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;
