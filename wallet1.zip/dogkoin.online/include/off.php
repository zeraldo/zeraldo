<?php  
if ( empty($_SESSION['user'])) {
 header("location: enter/enter.php");
}
?>