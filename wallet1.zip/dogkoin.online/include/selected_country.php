<option selected="selected" value="">Selecionar pais</option>
                            <option value="<?php echo '' . $pais;?>"><?php echo '' . $pais;?></option>