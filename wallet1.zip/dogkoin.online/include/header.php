<html lang="pt" dir="ltr">
   <head>
      <meta charset="UTF-8">
      <meta http-equiv="x-ua-compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta content="">
      <meta name="keywords" content="">
      <!-- Favicon-->
      <link rel="icon" href="assets/images/brand/favicon.png" type="image/x-icon">
      <!-- Title -->
      <title><?php echo $titulo; echo ' | '.$namesite;?></title>
      <!-- Bootstrap css -->
      <link href="assets/plugins/bootstrap-4.1.3/css/bootstrap.min.css" rel="stylesheet">
      <!-- Style css -->
      <link href="assets/css/style.css" rel="stylesheet">
      <!-- Default css -->
      <link href="assets/css/default.css" rel="stylesheet">
      <!-- Owl-carousel css-->
      <link href="assets/plugins/owl-carousel/owl.carousel.css" rel="stylesheet">
      <!-- Bootstrap-daterangepicker css -->
      <link rel="stylesheet" href="assets/plugins/bootstrap-daterangepicker/daterangepicker.css">
      <!-- Bootstrap-datepicker css -->
      <link rel="stylesheet" href="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.css">
      <!-- Custom scroll bar css -->
      <link href="assets/plugins/scroll-bar/jquery.mCustomScrollbar.css" rel="stylesheet">
      <!-- Horizontal css -->
      <link id="effect" href="assets/plugins/horizontal-menu/dropdown-effects/fade-up.css" rel="stylesheet">
      <link href="assets/plugins/horizontal-menu/horizontal.css" rel="stylesheet">
      <!-- P-scroll css -->
      <link href="assets/plugins/p-scroll/p-scroll.css" rel="stylesheet" type="text/css">
      <!-- Font-icons css -->
      <link href="assets/css/icons.css" rel="stylesheet">
      <!-- Rightsidebar css -->
      <link href="assets/plugins/sidebar/sidebar.css" rel="stylesheet">
      <!-- Nice-select css  -->
      <link href="assets/plugins/jquery-nice-select/css/nice-select.css" rel="stylesheet">
      <!-- Switcher css -->
      <link href="assets/switcher/css/switcher.css" rel="stylesheet" id="switcher-css" type="text/css" media="all">
      <!-- Color-palette css-->
      <link rel="stylesheet" href="assets/css/skins.css">
      <link rel="stylesheet" href="assets/switcher/demo.css">
      <style></style>
      <meta http-equiv="imagetoolbar" content="no">
	  
	  
<style type="text/css">

body, html {
    line-height: 1;
	 scroll-behavior: smooth;
   
    -webkit-transform: 100%;
}

@media (max-width: 1199px) {
.mobile2 {
	display: block; 
	margin: 0 auto; }
}

::-webkit-scrollbar-track {
    background-color: #F4F4F4;
}
::-webkit-scrollbar {
    width: 6px;
    background: #BCBCBC;
}
::-webkit-scrollbar-thumb {
    background: #3c4858;
}
</style>
	  
   </head>
   <body class="app dark-mode sidebar-gone">
      <div class="horizontalMenucontainer" style="min-width: 969px;">
         <!-- Loader -->
         <div id="loading" style="display: none;"> <img src="assets/images/other/loader-dark.svg" class="loader-img" alt="Loader"> </div>
         <!-- PAGE -->
         <div class="page">
            <div class="page-main">
               <!-- Top-header opened -->
               <div class="header-main header sticky">
                  <div class="app-header header top-header navbar-collapse ">
                     <div class="container">
                        <a id="horizontal-navtoggle" class="animated-arrow hor-toggle"><span></span></a>
                        <!-- sidebar-toggle-->
                        <div class="d-flex">
                           <a class="header-brand" href="index.php"> </a>
                           <div class="d-flex header-left left-header">
                              <!-- <div class="d-none d-lg-block horizontal">
                                 <ul class="nav">
                                 	<li class="">
                                 		<!-- <div class="dropdown d-none d-md-flex">
                                 	<a href="#" class="d-flex nav-link pr-0  pt-2 mt-3 country-flag1" data-toggle="dropdown"> <span class="d-flex"><img src="assets/images/us_flag.jpg" alt="img" class="avatar country-Flag mr-2 align-self-center"></span>
                                 				<div> <span class="d-flex fs-14 mr-3 mt-0">Portugues<span><i class="mdi mdi-chevron-down"></i></span></span>
                                 				</div>
                                 			</a>
                                 			<!-- <div class="dropdown-menu dropdown-menu-left dropdown-menu-arrow">
                                 				<a href="#" class="dropdown-item d-flex align-items-center mb-2"> <img src="assets/images/spain_flag.jpg" alt="flag-img" class="w-6 flag-sm mr-3 align-self-center">
                                 					<div> <span>Ingles</span> </div>
                                 				</a>
                                 			</div>
                                 			
                                 		</div>
                                 	</li>
                                 </ul>
                                 </div>-->
                           </div>
                           <div class="d-flex header-right ml-auto">
                              <!-- Cart -->
                              <div class="dropdown drop-profile">
                                 <div class="profile-details mt-1">
						<div style="margin: 40px 0px 0px 0px"> </div></div>
                              </div>
                              <!-- Right-side-toggle -->
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- Top-header closed -->
               <!-- Horizontal-menu -->
               <div class="horizontal-main hor-menu clearfix">
                  <div class="horizontal-mainwrapper container clearfix">
                     <nav class="horizontalMenu clearfix" style="height: 695px;">
                        <div class="overlapblackbg"></div>
                        <ul class="horizontalMenu-list">
                           <li aria-haspopup="true">
                               <a href="dashboard.php" class="sub-icon">
                              
				 <!-- <img src="assets/images/iconsvg/home.svg"  height="22" width="22"> -->
                                 INÍCIO
                              </a>
                             
                           </li>
						    
						   <li aria-haspopup="true"><a href="manag.php" class="">
						   <!-- <img src="assets/images/iconsvg/wallet.svg"  height="22" width="22">-->
						  GERENCIAR</a></li>
						     
						   <li aria-haspopup="true"><a href="parity.php" class="">
						   <!-- <img src="assets/images/iconsvg/wallet.svg"  height="22" width="22">-->
						  PARIDADES</a></li>
						   
							   <li aria-haspopup="true"><a href="histor.php" class="">
							   
							    <!-- <img src="assets/images/iconsvg/history.svg"  height="22" width="22">
							   -->
							   HISTÓRICO</a></li>
						
						   
						     <li aria-haspopup="true"><a href="profile.php" class="">
						   <!-- <img src="assets/images/iconsvg/wallet.svg"  height="22" width="22">-->
						   PERFIL</a></li>
						  

						     <li aria-haspopup="true"><a href="https://drive.google.com/uc?id=1kDy1IejFg75Wcb8Zy6ATLsJr-maRhja0&export=download" class="">
						   <!-- <img src="assets/images/iconsvg/wallet.svg"  height="22" width="22">-->
						   BAIXAR</a></li>						  
						    
                           </li>
						   
                        </ul>
                     </nav>
                     <!--Nav end -->
                  </div>
               </div>
			   
               <!-- Horizontal-menu end -->
			   
			  