<?php 
ini_set('display_errors', 0 );
error_reporting(-0);
 
session_start();
//Verifico se o usuário está logado no sistema
if (!isset($_SESSION["user"]) || $_SESSION["user"] != TRUE) {

require '../include/wew.php';
 
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
 if (isset($_POST['register'])) { 

$email = $mysqli->escape_string($_POST['email']);

$result = $mysqli->query("SELECT * FROM users WHERE email='$email'") or die($mysqli->error());

if ( $result->num_rows > 0 ) {

   //Endereço de email já existe
   echo '111';   
}

else {
 
$password = $mysqli->escape_string(md5 ($_POST['password']));

$senha = $mysqli->escape_string($_POST['password']);

$name = $mysqli->escape_string($_POST['name']);

$nome = $mysqli->escape_string($_POST['name']);
 
$id_one = mt_rand(10000000,99999999);

$hash = $mysqli->escape_string( md5( rand(0,1000)));

$data = date( "20y-m-d H:i:s");

$status = '1';

$_SESSION['user'] = $email;

//Pegar a data do usuario
require '../include/data.php';

//Incluir informaçoes do usuario, ip, navegador e o sistema operacional
require '../include/info_user.php'; 

//Envio de email
require '../mail/boas-vindas.php'; 
//Conta criada com sucesso
echo '100';

$data = date( "20y-m-d H:i:s");

$mysqli->query("INSERT INTO users (name, email, password, id_one,  data, status) " 
            . "VALUES ('$name','$email','$password','$id_one','$data','$status')");
    }
}

}

}
else {
//Sessão já existe
echo '100';
}
?>